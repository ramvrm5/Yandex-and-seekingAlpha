const functions = require('firebase-functions');
const admin = require('firebase-admin');
var serviceAccount = require("./permissions.json");
admin.initializeApp({
    credential: admin.credential.cert(serviceAccount),
    databaseURL: "https://autofeed2020.firebaseio.com"
});

const db = admin.firestore();
db.settings({ ignoreUndefinedProperties: true })

const axios = require('axios');
const cheerio = require("cheerio");
const fs = require("fs");
const json2csv = require("json2csv").Parser;
const htmlToText = require('html-to-text');

const moment = require('moment');

const express = require('express');
const cors = require('cors');
const { endianness } = require('os');
const app = express();

app.use(cors({ origin: true }));

let fecha = parseInt(moment(new Date()).format("x") / 1000);
let fechaClasica = new Date().toISOString()
let News_found = "NO"
let Arraydata = [{
    titulo: "",
    descripcion: "",
    cuerpo: "",
    img: "",
    url: "",
    fecha: fecha,
    fechaClasica: fechaClasica,
    fuente: '',
    tags: '',
    idioma: '',
}];
let tags = []

async function getAlltags() {
    try {
        let query = await db.collection('usuarios');
        await query.get()
            .then(async function (querySnapshot) {
                let docs = querySnapshot.docs;
                for (let doc of docs) {
                    if (doc.data().tags) {
                        for (let tag of doc.data().tags) {
                            let tempTags = tag.split(";")
                            for (let i = 0; tempTags.length > i; i++) {
                                tags.push(tempTags[i]);
                            }
                        }
                    }
                }
                //console.log(tags)
                seekingalpha()
            });
    } catch (error) {
        console.log(error);
    }
}


async function yandexNews() {
    for (let j = 0; tags.length > 0;) {
        console.log("tag :" + tags[j])
        if (tags[j]) {
            let yandexNews_tag = tags[j]
            let url_yandexNews = 'https://newssearch.yandex.ru/yandsearch?text=' + yandexNews_tag + '&rpt=nnews2&rel=rel&within=9';
            axios({
                method: 'get',
                url: url_yandexNews,
            }).then(response => {
                getData(response.data, "yandexNews", yandexNews_tag);

                const batch = db.batch();
                let arraytags = [];
                arraytags.push(yandexNews_tag);

                Arraydata.forEach(function (object, i, array) {
                    let unique_id = db.collection("my_collection").doc().id + "_yandexNews";
                    const Ref = db.collection('noticias2').doc('/' + unique_id + '/')
                    batch.set(Ref, {
                        titulo: object.title,
                        descripcion: object.description,
                        cuerpo: object.description,
                        img: object.img,
                        url: object.url,
                        fecha: fecha,
                        fechaClasica: fechaClasica,
                        fuente: 'yandex',
                        tags: arraytags,
                        idioma: 'es',
                    })
                })
                if (Arraydata.length == i + 1) {
                    j++
                }
                batch.commit().then(async function () {
                    await console.log('Done.')
                }).catch(err => console.log(`There was an error: ${err}`))
            }).catch(error => {
                console.log(error);
            })
        } else {
            j++
        }
    }
}

async function seekingalpha() {
    for (let j = 0; tags.length > 0;) {
        console.log("tag :" + tags[j])
        if (tags[j]) {
            let seekingalpha_tag = encodeURI(tags[j]);
            let url_seekingalpha = 'https://r4rrlsfs4a.execute-api.us-west-2.amazonaws.com/production/search?q=(and+%27' + seekingalpha_tag + '%27+(and+content_type:%27news%27)+(or+primary_symbols:%27%27))&q.parser=structured&sort=rank1+desc&size=10&q.options=%7B%22fields%22%3A%5B%22author%22%2C%22author_url%22%2C%22content%5E1%22%2C%22content_type%22%2C%22image_url%22%2C%22primary_symbols%22%2C%22secondary_symbols%22%2C%22summary%22%2C%22tags%22%2C%22title%5E3%22%2C%22uri%22%5D%7D&highlight.title=%7Bpre_tag%3A%27%3Cstrong%3E%27%2Cpost_tag%3A%27%3C%3C%3C%3Cstrong%3E%27%7D&highlight.summary=%7Bpre_tag%3A%27%3Cstrong%3E%27%2Cpost_tag%3A%27%3C%3C%3C%3Cstrong%3E%27%7D&highlight.content=%7Bpre_tag%3A%27%3Cstrong%3E%27%2Cpost_tag%3A%27%3C%3C%3C%3Cstrong%3E%27%7D&highlight.author=%7Bpre_tag%3A%27%3Cstrong%3E%27%2Cpost_tag%3A%27%3C%3C%3C%3Cstrong%3E%27%7D&highlight.primary_symbols=%7Bpre_tag%3A%27%3Cstrong%3E%27%2Cpost_tag%3A%27%3C%3C%3C%3Cstrong%3E%27%7D'
            await axios({
                method: 'get',
                url: url_seekingalpha,
            }).then(async function (response) {
                const batch = db.batch();
                getData(response.data.hits.hit, "seekingalpha", seekingalpha_tag);
                await Arraydata.forEach(function (object, i, array) {
                    let arraytags = [];
                    arraytags.push(seekingalpha_tag);
                    let unique_id_seekingalpha = db.collection("my_collection").doc().id + "_seekingApha";
                    const Ref = db.collection('noticias2').doc('/' + unique_id_seekingalpha + '/')
                    console.log("enter firebase forEach")
                    batch.set(Ref, {
                        titulo: object.title,
                        descripcion: object.description,
                        cuerpo: object.description,
                        img: object.img,
                        url: object.url,
                        fecha: fecha,
                        fechaClasica: fechaClasica,
                        fuente: 'seekingalpha',
                        tags: arraytags,
                        idioma: 'es',
                    })
                    if (Arraydata.length == i + 1) {
                        j++
                    }
                })
                batch.commit().then(async function () {
                    await console.log('Done.')
                }).catch(err => console.log(`There was an error: ${err}`))
            }).catch(error => {
                console.log(error);
            })
        } else {
            j++
        }
    }
    /* if (tagArray.length == i + 1) {
        seekingalpha()
    } */
}


async function getData(html, type, tag) {
    if (type == "yandexNews") {
        const $ = cheerio.load(html);
        $('ul.search-list li').each(async function () {
            title = $(this).find('div.document.i-bem h2 a').text();
            description = $(this).find('div.document.i-bem div.document__snippet').text();
            img = $(this).find('div.document.i-bem div.document__provider img').attr("src");
            url = $(this).find('div.document.i-bem h2 a').attr("href");
            tag = tag;
            await Arraydata.push({
                title: title,
                description: description,
                img: img,
                url: url,
                tag: tag,
                language: "es"
            });
        });
    } else if (type == "seekingalpha") {
        html.forEach(async function (object, i, array) {
            const text = htmlToText.fromString(object.highlights.content, {
                wordwrap: 130
            });
            title = object.fields.title;
            description = text;
            img = 'https://seekingalpha.com' + object.fields.image_url;
            url = 'https://seekingalpha.com' + object.fields.uri;
            tag = tag;

            await Arraydata.push({
                title: title,
                description: description,
                img: img,
                url: url,
                tag: tag,
                language: "es"
            });

        });
    }
    News_found = Arraydata.length > 1 ? "Yes" : "No";
    Arraydata.length > 1 ? Arraydata.shift() : Arraydata;
}

getAlltags();

exports.app = functions.https.onRequest(app);